# Setra Mahjong · سيترا ماجونغ

Real Android Mahjong Solitaire. Application ID: `com.mhmmad.setramahjong`; version 1.2.0 (3). The GitHub Actions default is the **Petal production build**. This source delivery has not been compiled/tested on a Huawei device in the current environment. Existing 1.1.0 Release APK is offline.

## Build

Use JDK 17 and Android SDK 36 / Build Tools 36.0.0. The complete Gradle 8.13 wrapper includes a distribution SHA-256 checksum. AGP 8.11.1, Kotlin 2.2.21, Compose BOM 2025.08.01, Room 2.8.3 (kapt) and DataStore 1.1.7 are pinned. minSdk 23; targetSdk 36. Desugaring 2.1.5 supports `java.time` on older devices.

Supply these environment variables from your private signing backup or CI Secrets:

- `SETRA_KEYSTORE_PATH`: absolute path to the existing key.
- `SETRA_STORE_PASSWORD`, `SETRA_KEY_ALIAS`, `SETRA_KEY_PASSWORD`.

Then run:

```sh
./gradlew :engine:test :app:assembleRelease :app:lintRelease
python3 tools/check_translations.py
python3 tools/verify_release.py app/build/outputs/apk/release/app-release.apk --sdk "$ANDROID_HOME"
```

A Release build fails early if signing information is missing. No task generates a key. Preserve the dedicated existing key forever and increase `versionCode` for updates. Update the explicit expected version checks in `tools/verify_release.py` and the workflow artifact label when releasing a new version.

## Code map

- `engine`: Android-independent rules, geometry, stable PRNG, 120 layouts, verified solution generator, immutable undo snapshots, shuffle, JSON session codec and tests.
- `app/data`: Room sessions/completions/counters, transactional first-clear rewards; additive database migration 1→2; DataStore preferences.
- `app/ui`: original botanical bitmap art with native Canvas tile materials and animations, board hit testing, zoom/pan, all screens and complete resource translations.
- `app/src/local`: offline advertising adapter; no advertising SDK dependency or network permission.
- `app/src/petal`: real Petal SDK implementation, compiled only when explicitly requested. SDK imports are verified against the pinned binary APIs.

## Visual update inherited from 1.1.0

Illustrated garden environment, 16 dimensional botanical symbols, jade-edged ivory tiles, animated atmosphere, illustrated chapter trail and victory bloom. Three persisted match effects: lotus bloom, jade spiral and petal flight. Reduced motion disables decorative loops and removes match delays. The package, database and signing identity are preserved.

## Rules and progress

Tiles occupy 2×2 units; higher overlapping faces block lower faces, and same-layer touching neighbours can close each side. Visual depth offsets never change the rules. Generation finds a complete geometric removal path, assigns equal symbols to its pairs, then replays and verifies every step. A verified initial solution does not guarantee success after any arbitrary move. Seeds and template version are saved along with the entire tile list, symbols, removed state, undo snapshots, counters and elapsed time. Shuffle preserves remaining geometry and symbol multiplicity; it returns failure rather than claiming success when no verified path is found within its search bound.

Each first campaign/daily completion earns 30 petals once, enforced by Room primary-key uniqueness and an atomic transaction. Backgrounds unlock at 0/90/300/900 petals; each fully completed chapter unlocks an ornament. Repeat completions can improve stars but do not grant petals again. Three stars: no assists; two: up to four hints/undos with no shuffle; otherwise one. Time does not affect stars.

## Advertising builds

Test: `./gradlew :app:assembleRelease -PpetalAds=true -PadsTestMode=true` uses only official Huawei test IDs. Do not click advertisements.

Production: the confirmed Setra ad-unit IDs (`l8o7yoez3b` banner; `c6r832l0lr` interstitial) are compiled into `BuildConfig` by default for the Petal flavour. Provide `SETRA_DEVELOPER_NAME`, `SETRA_CONTACT_EMAIL`, and `SETRA_PRIVACY_URL` (and the original keystore credentials). Build with `-PpetalAds=true` or run the production GitHub Actions workflow. Missing contact/published HTTPS privacy URL stops production Release. The local HTML template is **not** a publicly hosted URL. Keep it accurate and publish first.

The SDK and advertising providers stay disabled until data processing is allowed and the current SDK provider list is reviewed. Declining or withdrawing never blocks gameplay. Ads are non-personalised, tagged conservatively for child protection, classified W, and videos start muted. A dedicated banner area sits below the controls. An interstitial can be attempted only after a saved campaign result, beyond level 3, after at least three distinct completions since the previous ad and at least 180 seconds. A failed or late request never displays an ad automatically. No splash, exit, startup or mid-move ads.

Petal adds vendor providers and permissions. The manifest disables its providers by default and removes package inventory, UDID, MDM, download and fold-screen permissions. Two optional vendor SDK references have narrowly scoped R8 `dontwarn` rules; see the QA report for the tested scope. Production serving, successful actual Gradle build, real device coverage, privacy deployment, provider policy and dashboard filtering remain separate release checks for the 1.2.0 work.

## Testing and phone workflow

See `docs/Phone_Build_AR.md`, `docs/Ads_Integration_Report_1.2.0_AR.md`, and the **historical** `docs/QA_Report_1.1.0_AR.md`. `:app:assembleReleaseAndroidTest` builds a native Android instrumentation runner against the exact R8 Release target. The test APK is not a store deliverable. On a disposable emulator only, run `adb shell am instrument -w -e phase full com.mhmmad.setramahjong.test/com.mhmmad.setramahjong.QaInstrumentation`. The full phase resets local progress, tests a real database migration, plays campaign and daily puzzles, checks rewards and real touch input, and captures screenshots. Other phases are `prepare_restore`, `restore` and `large`; the Petal-only `ads` phase uses official test units and offline radios. See the QA report for actual results. Screenshots are actual emulator captures, not promotional mockups. Do not interpret emulator verification as a physical-device test.

No Firebase, Google Play Services, server, login, betting, cash prizes, music, people, animals or libGDX. The garden scene and 16-symbol atlas were created for this project with the built-in image generation tool; tile materials, animation paths and controls are native Canvas/Compose code. Asset provenance and prompts are in `art/Generated_Art_Provenance.md`. No third-party game artwork is used.

## Current delivery status

The 1.2.0 source was modified and passed static checks and translation checks. The old signing keystore was checked for matching certificate SHA-256 without distributing its private bytes. **No 1.2.0 APK has been built or signed in this environment** because the Android SDK and Gradle dependencies are not installed and external DNS downloads are unavailable. Run GitHub Actions with the original key and inspect its build result. Do not submit the 1.1.0 offline APK as the 1.2.0 ad-enabled build.
