package com.mhmmad.setramahjong.engine
import org.junit.Assert.*
import org.junit.Test
class EngineTest {
    @Test fun overlappingAndSideBlocking() {
        val t = listOf(Tile(0,0,0,0),Tile(1,2,0,0),Tile(2,4,0,0),Tile(3,1,1,1))
        assertEquals(setOf(2,3), Rules.freeIds(t).toSet())
        assertFalse(Rules.canMatch(t,0,2))
        assertEquals(setOf(0,2),Rules.freeIds(t.map { if(it.id==3) it.copy(removed=true) else it }).toSet())
        val shifted = listOf(Tile(0,0,0,0),Tile(1,2,1,0),Tile(2,-2,-1,0))
        assertFalse(0 in Rules.freeIds(shifted))
    }
    @Test fun rejectsMismatchesDuplicateCoveredAndRemoved() {
        val s=Generator.create(1,mode="tutorial")
        assertNull(Rules.match(s,0,0));assertNull(Rules.match(s,0,6));assertNull(Rules.match(s,4,5))
        val n=Rules.match(s,0,3)!!
        assertNull(Rules.match(n,0,3)); assertFalse(Rules.noMoves(n))
        assertEquals(8, Rules.undo(n)!!.remaining)
    }
    @Test fun allCampaignSolutionsAnd1200Seeds() {
        var count=0;var moves=0
        for(level in 1..120) for(i in 0..9) {
            val s=Generator.create(level,level*7919L+i*104729L)
            assertTrue("$level/$i",Rules.validateSolution(s.tiles,s.solution))
            assertEquals(s,SessionCodec.decode(SessionCodec.encode(s)))
            moves+=s.solution.size;count++
        }
        println("VERIFIED_GENERATED_BOARDS=$count VERIFIED_SOLUTION_STEPS=$moves TEMPLATES=120 FAMILIES=12")
    }
    @Test fun campaignCanonicalSeeds() {
        for(level in 1..120) {
            val s=Generator.create(level)
            assertEquals(s,Generator.create(level)); assertTrue(Rules.validateSolution(s.tiles,s.solution))
        }
    }
    @Test fun hintUndoShufflePersistence() {
        var s=Generator.create(87)
        repeat(8) { val p=Rules.hint(s)!!;assertTrue(Rules.canMatch(s.tiles,p.a,p.b));s=Rules.match(s,p.a,p.b)!! }
        val before=s
        val after=Generator.shuffle(s)!!
        assertEquals(before.tiles.map { Triple(it.id,it.x,it.z) },after.tiles.map { Triple(it.id,it.x,it.z) })
        assertEquals(before.tiles.filterNot(Tile::removed).groupingBy(Tile::symbol).eachCount(),after.tiles.filterNot(Tile::removed).groupingBy(Tile::symbol).eachCount())
        assertTrue(Rules.validateSolution(after.tiles,after.solution))
        val saved=SessionCodec.decode(SessionCodec.encode(after.copy(paused=true,elapsedSeconds=123,hints=2)))
        assertEquals(after.tiles,saved.tiles);assertEquals(after.history,saved.history)
        val undo=Rules.undo(after)!!
        assertEquals(before.history.last().tiles,undo.tiles)
    }
    @Test fun winAndDeadEndAreDistinct() {
        var s=Generator.create(1)
        for(p in s.solution) s=Rules.match(s,p.a,p.b)!!
        assertTrue(s.won);assertFalse(Rules.noMoves(s));assertNull(Rules.hint(s))
        val dead=s.copy(tiles=listOf(Tile(0,0,0,0,1),Tile(1,2,0,0,2)))
        assertTrue(Rules.noMoves(dead))
        val impossible=dead.copy(tiles=listOf(Tile(0,0,0,0,1),Tile(1,0,0,1,1)))
        assertNull(Generator.shuffle(impossible)); assertEquals(impossible.tiles,impossible.tiles)
    }
    @Test fun adFrequencyRules() {
        assertFalse(AdFrequency.eligible(3,8,8,500000,0))
        assertFalse(AdFrequency.eligible(4,3,3,170000,0))
        assertTrue(AdFrequency.eligible(4,3,3,180000,0))
        assertFalse(AdFrequency.eligible(9,8,2,900000,0))
        assertFalse(AdFrequency.eligible(9,8,4,100000,200000))
    }
    @Test fun arbitraryChoicesShuffleAndUndoRoundTrips() {
        var recovered=0
        for(level in 1..120) {
            var s=Generator.create(level)
            val random=StableRandom(level*31337L)
            repeat(12) {
                val pairs=Rules.availablePairs(s.tiles)
                if(pairs.isNotEmpty()) {
                    val before=s;val p=pairs[random.nextInt(pairs.size)]
                    s=Rules.match(s,p.a,p.b)!!
                    assertEquals(before.tiles,Rules.undo(s)!!.tiles)
                }
            }
            if(!s.won) {
                val n=Generator.shuffle(s)
                if(n!=null){assertTrue(Rules.validateSolution(n.tiles,n.solution));assertEquals(n,SessionCodec.decode(SessionCodec.encode(n)));recovered++}
            }
        }
        println("RANDOM_PLAY_VERIFIED_SHUFFLES=$recovered")
    }
}
