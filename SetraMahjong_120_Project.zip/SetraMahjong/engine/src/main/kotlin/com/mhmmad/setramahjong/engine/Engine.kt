package com.mhmmad.setramahjong.engine

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.abs

/** Coordinates use half-tile units. Every face occupies [x,x+2) × [y,y+2).
 * Rendering offsets are decorative and NEVER used for rules. */
@Serializable data class Tile(val id: Int, val x: Int, val y: Int, val z: Int, val symbol: Int = 0, val removed: Boolean = false)
@Serializable data class PairStep(val a: Int, val b: Int)
@Serializable data class Snapshot(val tiles: List<Tile>, val solution: List<PairStep>)
@Serializable data class Session(
    val key: String,
    val level: Int,
    val seed: Long,
    val templateVersion: Int = 1,
    val mode: String = "campaign",
    val tiles: List<Tile>,
    val solution: List<PairStep>,
    val history: List<Snapshot> = emptyList(),
    val moves: Int = 0,
    val hints: Int = 0,
    val undos: Int = 0,
    val shuffles: Int = 0,
    val elapsedSeconds: Long = 0,
    val paused: Boolean = false,
    val selectedId: Int? = null,
    val awarded: Boolean = false
) {
    val remaining: Int get() = tiles.count { !it.removed }
    val won: Boolean get() = remaining == 0
    val stars: Int get() = if (hints == 0 && undos == 0 && shuffles == 0) 3 else if (shuffles == 0 && hints + undos <= 4) 2 else 1
}
object SessionCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    fun encode(session: Session): String = json.encodeToString(Session.serializer(), session)
    fun decode(text: String): Session = json.decodeFromString(Session.serializer(), text).also {
        require(it.templateVersion == 1) { "Unsupported template version" }
        require(it.tiles.map(Tile::id).toSet().size == it.tiles.size)
        require(it.tiles.all { t -> t.symbol in 0..15 && t.z >= 0 })
    }
}

class Geometry(private val tiles: List<Tile>) {
    private val upper = tiles.associate { a -> a.id to tiles.filter { b -> b.z > a.z && abs(a.x - b.x) < 2 && abs(a.y - b.y) < 2 }.map(Tile::id) }
    private val left = tiles.associate { a -> a.id to tiles.filter { b -> b.z == a.z && b.x + 2 == a.x && abs(a.y - b.y) < 2 }.map(Tile::id) }
    private val right = tiles.associate { a -> a.id to tiles.filter { b -> b.z == a.z && a.x + 2 == b.x && abs(a.y - b.y) < 2 }.map(Tile::id) }
    fun free(id: Int, remaining: Set<Int>): Boolean = id in remaining &&
        upper.getValue(id).none { it in remaining } &&
        (left.getValue(id).none { it in remaining } || right.getValue(id).none { it in remaining })
    fun freeIds(remaining: Set<Int>): List<Int> = tiles.asSequence().map(Tile::id).filter { free(it, remaining) }.toList()
}
object Rules {
    fun freeIds(tiles: List<Tile>): List<Int> {
        val remaining = tiles.filterNot(Tile::removed).map(Tile::id).toSet()
        return Geometry(tiles).freeIds(remaining)
    }
    fun availablePairs(tiles: List<Tile>): List<PairStep> {
        val free = freeIds(tiles).toSet()
        val groups = tiles.filter { it.id in free }.groupBy(Tile::symbol)
        return buildList { groups.values.forEach { g -> for (a in g.indices) for (b in a + 1 until g.size) add(PairStep(g[a].id, g[b].id)) } }
    }
    fun canMatch(tiles: List<Tile>, a: Int, b: Int): Boolean {
        if (a == b) return false
        val ta = tiles.find { it.id == a } ?: return false
        val tb = tiles.find { it.id == b } ?: return false
        val free = freeIds(tiles)
        return ta.symbol == tb.symbol && a in free && b in free
    }
    fun match(s: Session, a: Int, b: Int): Session? {
        if (s.paused || s.won || !canMatch(s.tiles, a, b)) return null
        return s.copy(tiles = s.tiles.map { if (it.id == a || it.id == b) it.copy(removed = true) else it },
            history = s.history + Snapshot(s.tiles, s.solution), moves = s.moves + 1, selectedId = null)
    }
    fun undo(s: Session): Session? {
        if (s.history.isEmpty() || s.awarded) return null
        val old = s.history.last()
        return s.copy(tiles = old.tiles, solution = old.solution, history = s.history.dropLast(1), undos = s.undos + 1, selectedId = null)
    }
    fun hint(s: Session): PairStep? = availablePairs(s.tiles).firstOrNull()
    fun noMoves(s: Session): Boolean = !s.won && availablePairs(s.tiles).isEmpty()
    fun validateSolution(tiles: List<Tile>, steps: List<PairStep>): Boolean {
        val g = Geometry(tiles)
        val remaining = tiles.filterNot(Tile::removed).map(Tile::id).toMutableSet()
        val byId = tiles.associateBy(Tile::id)
        for ((a, b) in steps) {
            if (a == b || !g.free(a, remaining) || !g.free(b, remaining) || byId[a]?.symbol != byId[b]?.symbol) return false
            remaining.remove(a); remaining.remove(b)
        }
        return remaining.isEmpty()
    }
}
/** Explicit PRNG algorithm, independent of Kotlin Random implementation changes. */
class StableRandom(seed: Long) {
    private var value = seed
    fun nextLong(): Long {
        value += -7046029254386353131L
        var z = value
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        return z xor (z ushr 31)
    }
    fun nextInt(bound: Int): Int = ((nextLong() ushr 1) % bound).toInt()
    fun <T> shuffle(list: List<T>): List<T> = list.toMutableList().also { a ->
        for (i in a.lastIndex downTo 1) { val j = nextInt(i + 1); val old = a[i]; a[i] = a[j]; a[j] = old }
    }
}
object Layouts {
    const val VERSION = 1
    const val LEVELS = 120
    /** Twelve hand-authored silhouettes. Entries are HALF row widths, top to bottom.
     * Mirrored layers preserve an even exposed frontier; later variants add gaps,
     * staggered caps and upper bridges, rather than only adding tile count. */
    private val silhouettes = listOf(
        listOf(1, 2, 2, 1),                 // sprout
        listOf(1, 2, 3, 2, 1),              // lotus
        listOf(1, 3, 2, 3, 1),              // star
        listOf(1, 2, 3, 3, 2, 1),           // leaf
        listOf(3, 3, 2, 2, 3, 3),           // courtyard
        listOf(1, 2, 3, 4, 3, 2, 1),        // pyramid
        listOf(2, 3, 2, 3, 2),              // lattice
        listOf(1, 3, 4, 3, 1),              // rosette
        listOf(2, 3, 3, 2, 3, 3, 2),        // arch
        listOf(1, 2, 3, 4, 4, 3, 2, 1),     // lantern garden
        listOf(3, 2, 4, 3, 4, 2, 3),        // mosaic
        listOf(2, 3, 4, 3, 4, 3, 2)         // sanctuary
    )
    fun tiles(level: Int): List<Tile> {
        require(level in 1..LEVELS)
        val chapter = (level - 1) / 10
        val variant = (level - 1) % 10
        val widths = silhouettes[chapter]
        val result = mutableListOf<Tile>()
        fun row(width: Int, y: Int, z: Int, gap: Int = 0) {
            for (col in 0 until width) {
                val x = gap + col * 2
                result += Tile(result.size, x, y, z)
                result += Tile(result.size, -x - 2, y, z)
            }
        }
        widths.forEachIndexed { i, width ->
            val gap = if (variant in setOf(3, 6, 9) && i % 3 == 1) 2 else 0
            row(width + if (variant == 8 && i == widths.size / 2) 1 else 0, i * 2, 0, gap)
        }
        val layers = when { level <= 2 -> 0; chapter < 2 -> 1; chapter < 6 -> 2; else -> 3 }
        for (z in 1..layers) {
            for (i in 1 until widths.lastIndex) {
                val width = (widths[i] - z - if ((i + variant) % 3 == 0) 1 else 0).coerceAtLeast(0)
                if (width > 0) row(width, i * 2 + if (variant % 2 == 1) 1 else 0, z)
            }
        }
        return result
    }
    fun tutorial(): List<Tile> = listOf(
        Tile(0, 0, 0, 0, 0), Tile(1, 2, 0, 0, 1), Tile(2, 4, 0, 0, 1), Tile(3, 6, 0, 0, 0),
        Tile(4, 2, 3, 0, 3), Tile(5, 4, 3, 0, 3), Tile(6, 2, 3, 1, 2), Tile(7, 4, 3, 1, 2)
    )
}
object Generator {
    /** Symbol-independent geometric DFS. A bounded search returns null on failure;
     * it never relabels a random dead board as solvable. */
    fun geometryPath(tiles: List<Tile>, seed: Long, maxNodes: Int = 60_000): List<PairStep>? {
        val g = Geometry(tiles)
        val remaining = tiles.filterNot(Tile::removed).map(Tile::id).toMutableSet()
        if (remaining.size % 2 != 0) return null
        val random = StableRandom(seed)
        val dead = HashSet<String>()
        var nodes = 0
        fun visit(): List<PairStep>? {
            if (remaining.isEmpty()) return emptyList()
            if (++nodes > maxNodes) return null
            val key = remaining.sorted().joinToString(",")
            if (key in dead) return null
            val free = g.freeIds(remaining)
            if (free.size < 2) return null
            val candidates = random.shuffle(buildList {
                for (i in free.indices) for (j in i + 1 until free.size) add(PairStep(free[i], free[j]))
            })
            for (p in candidates) {
                remaining.remove(p.a); remaining.remove(p.b)
                val tail = visit()
                remaining.add(p.a); remaining.add(p.b)
                if (tail != null) return listOf(p) + tail
                if (nodes > maxNodes) break
            }
            dead += key
            return null
        }
        return visit()
    }
    fun create(level: Int, seed: Long = 0x5345545241L + level * 7919L, mode: String = "campaign", key: String = "campaign:$level"): Session {
        if (mode == "tutorial") return Session(key, 1, 0L, mode = mode, tiles = Layouts.tutorial(),
            solution = listOf(PairStep(0, 3), PairStep(1, 2), PairStep(6, 7), PairStep(4, 5)))
        val base = Layouts.tiles(level)
        val path = requireNotNull(geometryPath(base, seed)) { "Template has no verified geometry path: $level/$seed" }
        val random = StableRandom(seed xor 0xDEC0DEL)
        // More copies per symbol produce tempting alternatives at later levels.
        val variety = when { level <= 2 -> 12; level < 21 -> 10; level < 61 -> 8; else -> 6 }
        val mapping = mutableMapOf<Int, Int>()
        path.forEach { p -> val symbol = random.nextInt(variety); mapping[p.a] = symbol; mapping[p.b] = symbol }
        val tiles = base.map { it.copy(symbol = mapping.getValue(it.id)) }
        check(Rules.validateSolution(tiles, path))
        return Session(key, level, seed, mode = mode, tiles = tiles, solution = path)
    }
    fun shuffle(s: Session): Session? {
        if (s.won || s.paused) return null
        val seed = s.seed xor ((s.shuffles + 1L) * 104729L) xor s.moves.toLong()
        val path = geometryPath(s.tiles, seed) ?: return null
        val counts = s.tiles.filterNot(Tile::removed).groupingBy(Tile::symbol).eachCount()
        if (counts.values.any { it % 2 != 0 }) return null
        val symbols = StableRandom(seed).shuffle(counts.flatMap { (symbol, count) -> List(count / 2) { symbol } })
        val map = mutableMapOf<Int, Int>()
        path.forEachIndexed { i, p -> map[p.a] = symbols[i]; map[p.b] = symbols[i] }
        val tiles = s.tiles.map { if (it.removed) it else it.copy(symbol = map.getValue(it.id)) }
        check(Rules.validateSolution(tiles, path))
        // History snapshots include symbols. Undo across a shuffle is exact.
        return s.copy(tiles = tiles, solution = path, shuffles = s.shuffles + 1, selectedId = null)
    }
}
/** Persist timestamps/counts outside the SDK. An ad is possible only at a result
 * transition, and only after three OTHER completed stages. */
object AdFrequency {
    fun eligible(level: Int, completedBefore: Int, completionsSinceAd: Int, now: Long, lastAd: Long): Boolean =
        level > 3 && completedBefore >= 3 && completionsSinceAd >= 3 && now >= lastAd && now - lastAd >= 180_000L
}
