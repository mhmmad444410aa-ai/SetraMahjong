#!/usr/bin/env python3
"""Checks bytes produced by Gradle; never substitutes a Debug APK."""
import argparse,hashlib,json,re,subprocess,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('apk',type=Path);p.add_argument('--sdk',required=True,type=Path);p.add_argument('--output',type=Path,default=Path('release-checks'));p.add_argument('--advertising',choices=['offline','test','production'],default='production');a=p.parse_args()
tools=a.sdk/'build-tools/36.0.0';a.output.mkdir(parents=True,exist_ok=True)
def run(*args):return subprocess.check_output([str(x) for x in args],stderr=subprocess.STDOUT,text=True)
sig=run(tools/'apksigner','verify','--verbose','--print-certs',a.apk)
cert=re.search(r'Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]+)',sig).group(1).lower()
expected=(Path(__file__).resolve().parents[1]/'docs/signing-certificate-sha256.txt').read_text().strip().lower().replace(':','')
assert cert==expected,'Signing identity changed; do not publish as an update'
badging=run(tools/'aapt','dump','badging',a.apk)
assert "package: name='com.mhmmad.setramahjong'" in badging
assert "versionCode='3'" in badging and "versionName='1.2.0'" in badging
assert "sdkVersion:'23'" in badging and "targetSdkVersion:'36'" in badging
assert 'application-debuggable' not in badging
align=run(tools/'zipalign','-c','-P','16','-v','4',a.apk)
# Inspect the compiled DEX, not merely the Gradle source. Prevent uploading an
# offline or test-ID APK accidentally under the production release label.
with zipfile.ZipFile(a.apk) as archive:
    dex=b''.join(archive.read(n) for n in archive.namelist() if re.match(r'classes[0-9]*\.dex$',n))
assert dex, 'No DEX code found in APK'
if a.advertising=='production':
    assert b'l8o7yoez3b' in dex and b'c6r832l0lr' in dex, 'Production ad unit IDs missing from APK'
elif a.advertising=='test':
    assert b'testw6vs28auh3' in dex and b'teste9ih9j0rc3' in dex, 'Test ad unit IDs missing from APK'
else:
    assert b'com.huawei.hms.ads.HwAds' not in dex, 'Unexpected Petal implementation in offline APK'
apk_hash=hashlib.sha256(a.apk.read_bytes()).hexdigest()
(a.output/'signature.txt').write_text(sig);(a.output/'badging.txt').write_text(badging);(a.output/'alignment.txt').write_text(align)
data={'package':'com.mhmmad.setramahjong','versionName':'1.2.0','versionCode':3,'debuggable':False,'certificate_sha256':cert,'apk_sha256':apk_hash,'advertising':a.advertising,'size_bytes':a.apk.stat().st_size}
(a.output/'verification.json').write_text(json.dumps(data,indent=2));print(json.dumps(data,indent=2))
