#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as E
import re
r=Path(__file__).resolve().parents[1]/'app/src/main/res'
base=E.parse(r/'values/strings.xml').getroot();names={(x.tag,x.attrib['name']) for x in base}
for folder in ['values-en-rGB','values-ar','values-pt-rBR']:
 tree=E.parse(r/folder/'strings.xml').getroot();actual={(x.tag,x.attrib['name']) for x in tree}
 assert names==actual,(folder,names-actual,actual-names)
 for node in tree.findall('string'):
  b=base.find(f"string[@name='{node.attrib['name']}']")
  assert sorted(re.findall(r'%\d+\$[ds]',b.text or ''))==sorted(re.findall(r'%\d+\$[ds]',node.text or '')),node.attrib['name']
  assert (node.text or '').strip()
 print(folder,'PASS:',len(actual),'resource entries; format placeholders complete')
