#!/usr/bin/env python3
"""Static checks only: does not prove successful SDK runtime ad impressions."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
gradle=(p/'app/build.gradle.kts').read_text()
provider=(p/'app/src/petal/java/com/mhmmad/setramahjong/ads/PetalProvider.kt').read_text()
flow=(p/'.github/workflows/release.yml').read_text()
verify=(p/'tools/verify_release.py').read_text()
for expected in ['com.mhmmad.setramahjong','versionCode = 3','versionName = "1.2.0"',
 'l8o7yoez3b','c6r832l0lr','ads-prime:3.4.91.301','ads-consent:3.4.91.301']:
 assert expected in gradle, expected
for expected in ['BannerView','InterstitialAd','setNonPersonalizedAd(1)','Consent.getInstance']:
 assert expected in provider, expected
assert 'default: production' in flow
assert "versionCode='3'" in verify and "versionName='1.2.0'" in verify
assert (p/'docs/signing-certificate-sha256.txt').read_text().strip().replace(':','').lower() == '7cf0f4de2660de102cf10aeae0d62fd3f33e441f47d390a7b9322702d6fd13ec'
print('Static Setra Mahjong 1.2.0 integration checks passed (not a build or device test).')
