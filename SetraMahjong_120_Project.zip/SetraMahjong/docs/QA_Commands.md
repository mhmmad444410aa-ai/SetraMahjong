# Reproducing verification

Use a disposable emulator, with no personal game progress. `full` intentionally creates a database-v1 fixture then resets progress. Keep the store signing key private and supply it through the same environment/Secrets used for Release.

```sh
./gradlew :engine:test :app:assembleRelease :app:assembleReleaseAndroidTest :app:lintRelease
adb install -r app/build/outputs/apk/release/app-release.apk
adb install -r app/build/outputs/apk/androidTest/release/app-release-androidTest.apk
adb shell svc wifi disable
adb shell svc data disable
adb shell am instrument -w -e phase full com.mhmmad.setramahjong.test/com.mhmmad.setramahjong.QaInstrumentation
adb shell am instrument -w -e phase prepare_restore com.mhmmad.setramahjong.test/com.mhmmad.setramahjong.QaInstrumentation
adb shell am force-stop com.mhmmad.setramahjong
adb shell am instrument -w -e phase restore com.mhmmad.setramahjong.test/com.mhmmad.setramahjong.QaInstrumentation
adb install -r app/build/outputs/apk/release/app-release.apk
adb shell am instrument -w -e phase restore com.mhmmad.setramahjong.test/com.mhmmad.setramahjong.QaInstrumentation
adb shell wm size 640x1136
adb shell settings put system font_scale 1.5
adb shell am instrument -w -e phase large com.mhmmad.setramahjong.test/com.mhmmad.setramahjong.QaInstrumentation
adb shell wm size reset
adb shell settings put system font_scale 1.0
```

Pull screenshots from `Android/data/com.mhmmad.setramahjong/files/qa` on shared storage, and the corresponding `qa-navigation`, `qa-touch`, `qa-restore` and `qa-large` folders. These are real captures made by the separate test APK. No test fixture or test instrumentation component is included in the normal application APK.

For an explicit SDK test, build and install both APKs with `-PpetalAds=true -PadsTestMode=true`, turn Wi-Fi/mobile data off, then run `phase ads`. This loads the real BannerView and InterstitialAd with the documented official test IDs and verifies that a failing SDK request does not block matching. It does not click or display production advertisements. The test consent fixture is confined to the test APK; the app's normal consent/provider-list path remains separate.

The SDK optional sources are excluded from the default build. Rebuild without `-PpetalAds=true` to produce the offline Release. Never submit the test APK or the SDK test variant as the reviewed offline build.
