# Setra Mahjong — Store listing 1.2.0

Package: com.mhmmad.setramahjong · versionCode: 2

## العربية

**اسم التطبيق:** سيترا ماجونغ

**وصف قصير:** طابق الأزواج واكتشف ١٢٠ مرحلة وحدائق هادئة وتحديًا يوميًا دون إنترنت.

**وصف طويل:**

ادخل حديقة سيترا ماجونغ، لعبة Mahjong Solitaire لمطابقة أزواج البلاطات، برسوم نباتية وزخارف هندسية أصلية وألوان زمردية وعاجية هادئة.

اختر بلاطتين متطابقتين ومتاحَتين، وأزلهما لتفتح مسارات جديدة في اللوحة. تكون البلاطة متاحة عندما لا تغطيها بلاطة باقية من طبقة أعلى ويكون أحد جانبيها الأيسر أو الأيمن مفتوحًا. فكّر قبل الاختيار: وجود حل في البداية لا يجعل كل اختيار ناجحًا.

• مشهد حديقة مرسوم، و١٦ رمزًا نباتيًا وزخرفيًا واضحًا، وبلاطات بعُمق بصري وحواف من اليشم.
• ثلاث حركات مطابقة محفوظة الاختيار: تفتّح اللوتس، ودوّامة اليشم، وطيران البتلات، مع خيار تقليل الحركة.
• ١٢٠ مرحلة موزعة على ١٢ فصلًا بأشكال نباتية ونجوم وأقواس وفسيفساء.
• طبقات واختيارات ومسارات مختلفة تتدرج في التحدي.
• تدريب تفاعلي يوضح المطابقة والحجب.
• تلميح لزوج متاح، وتراجع، وإعادة ترتيب قابلة للحل عندما تسمح هندسة البلاطات المتبقية.
• تحدٍ يومي محلي مرتبط بتاريخ الجهاز، دون حساب أو لوحة ترتيب.
• ثلاث نجوم ممكنة لكل مرحلة؛ الوقت لا يؤثر في النجوم.
• بتلات للإكمال الأول تفتح خلفيات جديدة، وزخارف تُجمع بإكمال الفصول.
• تكبير وتحريك للوحة، وحفظ التقدم واستكمال اللعب.
• إحصاءات فعلية وخيارات للمؤثرات الخفيفة والاهتزاز وتقليل الحركة.
• دعم كامل للعربية والإنجليزية البريطانية والبرتغالية البرازيلية.

العب منذ أول تشغيل دون إنترنت. تُحفظ بيانات اللعب محليًا على جهازك. لا حساب أو خادم أو مزامنة سحابية. لا موسيقى أو أشخاص أو حيوانات، ولا مراهنات أو جوائز نقدية أو شراء فرص عشوائية.

قد تظهر إعلانات بانر وشاشة كاملة بين المراحل في إصدار 1.2.0 عند توفر الموافقات اللازمة. اللعب والمساعدات الأساسية لا يتطلبان مشاهدة إعلان.

## English (United Kingdom)

**App name:** Setra Mahjong

**Short description:** Match pairs across 120 original layouts, quiet gardens and a local daily puzzle.

**Full description:**

Make room for a little calm with Setra Mahjong, an original Mahjong Solitaire game of matching tile pairs. Explore emerald gardens, warm ivory tiles and clear botanical and geometric symbols.

Match two identical free tiles to open a path through each layered board. A tile is free when no remaining tile overlaps it from above and at least one of its left or right sides is open. Every starting board has a verified solution, but your choices still matter: some paths may need an undo.

• An illustrated garden, 16 detailed botanical and geometric symbols, and ivory tiles with jade edges.
• Three saved match-animation choices: lotus bloom, jade spiral and petal flight, with reduced motion.
• 120 levels across twelve gardens, with leaves, stars, arches and mosaic silhouettes.
• Layered layouts and changing choices, with more than simply increasing tile counts.
• A short interactive guide to matching and blocked tiles.
• Real hints, accurate undo, and a solvable shuffle whenever the remaining geometry permits it.
• A local daily garden based on the device date, without accounts or leaderboards.
• Up to three stars per level; time never affects stars.
• First-clear petals that unlock backgrounds, plus ornaments earned by completing chapters.
• Pinch to zoom, drag to explore, and saved boards you can resume.
• Real statistics, optional soft sound effects, vibration and reduced motion.
• Complete English (UK), Arabic and Portuguese (Brazil) language support.

Core play works offline from the first launch. Your game data stays in local app storage. There is no account, game server or cloud synchronisation. No music, people, animals, wagers, cash prizes or random chance purchases.

The advertising-enabled 1.2.0 build may display banners and interstitial adverts between levels when the required permissions are in place. Core play and assists never require watching an advert.

## Português (Brasil)

**Nome do aplicativo:** Setra Mahjong

**Descrição curta:** Combine pares em 120 fases originais, jardins tranquilos e um desafio diário.

**Descrição completa:**

Abra espaço para a calma com Setra Mahjong, um jogo original de Mahjong Solitaire para combinar pares de peças. Explore jardins em verde-esmeralda, peças em marfim e símbolos botânicos e geométricos fáceis de reconhecer.

Combine duas peças idênticas e livres para abrir caminhos pelo tabuleiro. Uma peça está livre quando nenhuma peça restante de uma camada superior se sobrepõe a ela e pelo menos um dos lados, esquerdo ou direito, está aberto. Cada tabuleiro inicial tem uma solução verificada, mas suas escolhas importam: alguns caminhos podem exigir que você desfaça uma jogada.

• Jardim ilustrado, 16 símbolos botânicos e geométricos detalhados e peças em marfim com bordas de jade.
• Três animações de pares com escolha salva: flor de lótus, espiral de jade e voo das pétalas, com movimento reduzido.
• 120 fases em doze jardins, com formas de folhas, estrelas, arcos e mosaicos.
• Tabuleiros em camadas e escolhas variadas, além do simples aumento de peças.
• Guia interativo sobre combinações e peças bloqueadas.
• Dicas reais, desfazer preciso e embaralhamento com solução quando a geometria restante permitir.
• Jardim diário local baseado na data do aparelho, sem conta ou classificação online.
• Até três estrelas por fase; o tempo nunca afeta as estrelas.
• Pétalas pela primeira conclusão para desbloquear fundos e ornamentos ao concluir capítulos.
• Amplie com dois dedos, arraste para explorar e retome tabuleiros salvos.
• Estatísticas reais, efeitos sonoros suaves opcionais, vibração e movimento reduzido.
• Suporte completo a português do Brasil, inglês britânico e árabe.

O jogo principal funciona sem internet desde a primeira abertura. Os dados ficam no armazenamento local do aplicativo. Não há conta, servidor de jogo nem sincronização na nuvem. Sem música, pessoas, animais, apostas, prêmios em dinheiro ou compra de chances aleatórias.

A versão 1.2.0 com publicidade pode exibir banners e anúncios intersticiais entre fases após as autorizações necessárias. O jogo principal e as ajudas nunca exigem assistir a anúncios.

## Submission notes — not listing copy

- Publisher name and contact email: not supplied; must be completed in the policy and production build.
- The standalone HTML is a policy file, not a published privacy URL.
- Category proposal: Games / Puzzle, subject to the store’s current choices.
- Complete the actual content/advertising age-rating questionnaire. Do not claim an official rating in advance.
- Distribution proposal: outside mainland China. Do not select mainland China until the applicable game qualifications/publication approvals are verified.
- Distinctive content: 12 original silhouettes, verified pair-removal generation, layered blockers, local daily seeds, tactile vector tile artwork and chapter-based collectables. Store similarity review remains discretionary.
- 6 real emulator screenshots per locale are delivered separately. They show automated gameplay progress; no progress is preloaded in the distributed APK.
- No acceptance, revenue, trademark clearance or name reservation is guaranteed.
