# Official sources checked on 15 November 2026

- Android AGP 8.11 compatibility: https://developer.android.com/build/releases/agp-8-11-0-release-notes — supports API 36 with Gradle 8.13 and JDK 17. This project uses 8.11.1.
- Petal SDK history: https://developer.huawei.com/consumer/en/doc/hmscore-guides/publisher-service-version-change-history-0000001050066909/
- Actual Maven metadata resolved and pinned: https://developer.huawei.com/repo/com/huawei/hms/ads-prime/maven-metadata.xml and https://developer.huawei.com/repo/com/huawei/hms/ads-consent/maven-metadata.xml — both returned 3.4.91.301. This differs slightly from the version shown in the retrieved history page; compilation uses the repository bytes, not copied legacy samples.
- Banner SDK integration and official test ID: https://developer.huawei.com/consumer/en/doc/hmscore-guides/publisher-service-banner-0000001050066915/
- Interstitial integration and image test ID `teste9ih9j0rc3`: https://developer.huawei.com/consumer/en/doc/hmscore-guides/publisher-service-interstitial-0000001050064970/
- Consent and provider list requirements: https://developer.huawei.com/consumer/en/doc/hmscore-guides/publisher-service-consent-settings-0000001075342977/
- APK asset specifications: https://developer.huawei.com/consumer/en/doc/app/agc-help-app-material-requirement-0000001146534651/ — 3–8 APK screenshots; 320–3840 px side lengths; PNG/JPEG up to 2 MB; 216 or 512 px icon. This is the APK section, not the separate HarmonyOS asset table.
- APK release flow: https://developer.huawei.com/consumer/en/doc/doccenter-distribution/agc-help-releaseapkrpk-0000001106463276/
- App metadata, similarity, privacy and rating review: https://developer.huawei.com/consumer/en/doc/50106/
- Mainland China game qualifications/publication approvals: https://developer.huawei.com/consumer/en/doc/app/80301/

## What this verifies

The toolchain supports API 36, actual SDK artifacts resolve, and the image dimensions fit the retrieved APK asset limits. No universal current AppGallery APK target-SDK deadline was established by the retrieved official submission pages; check the app’s live submission console before release. Target 36 is the implementation choice verified by building and running the game, not a claim that every AppGallery market mandates exactly 36.

The name is short and uses neither Vita nor reference artwork. No trademark registry clearance, AppGallery name reservation or acceptance was performed. Original layouts, project-created botanical artwork, native tile materials and animations, and album progression differentiate this implementation; similarity review can still reject a game. The actual publisher identity/contact details and a published HTTPS privacy policy must be supplied before submission. Fill the real age/content/advertising questionnaire without assuming a pre-approved rating. Mainland China is outside the proposed initial distribution scope.

## Values and advertising categories

The app itself contains plants, flowers, architecture and geometry only, no music, people or animals. Production ads are disabled. The optional SDK requests non-personalised ads, classification W and muted video. These controls do not guarantee that every third-party creative will fit the publisher’s values. Before enabling production ads, use the current Petal Publisher Center blocking controls for the categories/advertisers/URLs actually available to the account, especially gambling, alcohol, adult content, dating and other unsuitable material. Those dashboard settings were not applied: no Setra ad units or authenticated publisher-console task were supplied. Review actual ad behaviour on authorised test devices before switching to real IDs.
