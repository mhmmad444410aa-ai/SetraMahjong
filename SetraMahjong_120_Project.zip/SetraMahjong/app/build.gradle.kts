plugins {
    id("com.android.application")
    kotlin("android")
    kotlin("kapt")
    kotlin("plugin.serialization")
    id("org.jetbrains.kotlin.plugin.compose")
}
fun quoted(value:String):String="\""+value.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\""
fun secret(name: String): String? = System.getenv(name)?.takeIf { it.isNotBlank() }
val keyPath = secret("SETRA_KEYSTORE_PATH")
val petalEnabled = providers.gradleProperty("petalAds").orNull == "true"
android {
    namespace = "com.mhmmad.setramahjong"
    compileSdk = 36
    buildToolsVersion = "36.0.0"
    testBuildType = "release"
    bundle { language { enableSplit = false } }
    defaultConfig {
        applicationId = "com.mhmmad.setramahjong"
        minSdk = 23
        targetSdk = 36
        versionCode = 3
        versionName = "1.2.0"
        testInstrumentationRunner = "com.mhmmad.setramahjong.QaInstrumentation"
        buildConfigField("boolean", "PETAL_ENABLED", petalEnabled.toString())
        buildConfigField("String", "BANNER_ID", quoted("l8o7yoez3b"))
        buildConfigField("String", "INTERSTITIAL_ID", quoted("c6r832l0lr"))
        buildConfigField("boolean", "ADS_TEST_MODE", (providers.gradleProperty("adsTestMode").orNull == "true").toString())
        buildConfigField("String", "DEVELOPER_NAME", quoted(secret("SETRA_DEVELOPER_NAME") ?: ""))
        buildConfigField("String", "CONTACT_EMAIL", quoted(secret("SETRA_CONTACT_EMAIL") ?: ""))
        buildConfigField("String", "PRIVACY_URL", quoted(secret("SETRA_PRIVACY_URL") ?: ""))
        kapt { arguments { arg("room.schemaLocation", "$projectDir/schemas") } }
    }
    signingConfigs {
        create("setra") {
            if (keyPath != null) {
                storeFile = file(keyPath)
                storePassword = secret("SETRA_STORE_PASSWORD")
                keyAlias = secret("SETRA_KEY_ALIAS")
                keyPassword = secret("SETRA_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isDebuggable = false
            testProguardFiles("proguard-test.pro")
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("setra")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    sourceSets["main"].java.srcDir(if (petalEnabled) "src/petal/java" else "src/local/java")
    if (petalEnabled) sourceSets["androidTest"].java.srcDir("src/petalAndroidTest/java")
    if (petalEnabled) sourceSets["main"].manifest.srcFile("src/petal/AndroidManifest.xml")
    packaging { resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1") }
    lint { abortOnError = true; checkReleaseBuilds = true }
}
kapt { correctErrorTypes = true }
dependencies {
    implementation(project(":engine"))
    implementation(platform("androidx.compose:compose-bom:2025.08.01"))
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.room:room-runtime:2.8.3")
    implementation("androidx.room:room-ktx:2.8.3")
    kapt("androidx.room:room-compiler:2.8.3")
    implementation("androidx.datastore:datastore-preferences:1.1.7")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    if (petalEnabled) {
        implementation("com.huawei.hms:ads-prime:3.4.91.301")
        implementation("com.huawei.hms:ads-consent:3.4.91.301")
    }
}
// Fail before compilation; never silently fall back to a debug key.
tasks.register("verifyReleaseSigning") {
    doLast {
        listOf("SETRA_KEYSTORE_PATH", "SETRA_STORE_PASSWORD", "SETRA_KEY_ALIAS", "SETRA_KEY_PASSWORD").forEach {
            require(!secret(it).isNullOrBlank()) { "Missing required signing secret: $it" }
        }
        require(file(keyPath!!).isFile) { "Signing keystore not found" }
        if (petalEnabled && providers.gradleProperty("adsTestMode").orNull != "true") {
            listOf("SETRA_DEVELOPER_NAME", "SETRA_CONTACT_EMAIL", "SETRA_PRIVACY_URL").forEach {
                require(!secret(it).isNullOrBlank()) { "Production Petal build requires $it" }
            }
            require(secret("SETRA_PRIVACY_URL")!!.startsWith("https://")) { "Published privacy policy must be an HTTPS URL" }
            require("@" in secret("SETRA_CONTACT_EMAIL")!!) { "Supply a publisher contact email" }
        }
    }
}
tasks.matching { it.name == "preReleaseBuild" }.configureEach { dependsOn("verifyReleaseSigning") }
