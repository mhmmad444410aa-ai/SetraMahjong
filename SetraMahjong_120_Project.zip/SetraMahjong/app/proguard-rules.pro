-keepattributes Signature,InnerClasses,EnclosingMethod,RuntimeVisibleAnnotations
-keep class com.mhmmad.setramahjong.engine.**$$serializer { *; }
-keepclassmembers class com.mhmmad.setramahjong.engine.** { *** Companion; }
# Petal SDK documentation requires preserving its public implementation.
-keep class com.huawei.hms.ads.** { *; }
-keep class com.huawei.openalliance.ad.** { *; }
-keep class com.huawei.hms.ads.consent.** { *; }
-dontwarn com.huawei.openalliance.ad.**
# Optional vendor-framework / optional AppGallery logging references in Petal 3.4.91.301.
-dontwarn com.huawei.android.app.PackageManagerEx
-dontwarn com.huawei.appgallery.log.LogAdaptor
# Stable persisted/domain API also supports instrumentation of the same R8 target.
-keep class com.mhmmad.setramahjong.engine.** { *; }
-keep class com.mhmmad.setramahjong.data.** { *; }
-keep class com.mhmmad.setramahjong.GameViewModel { public *; }

-keep class com.mhmmad.setramahjong.GameUi { public *; }
# AndroidJUnitRunner uses this shared AndroidX API when testing the R8 target.
-keep class androidx.tracing.** { *; }
# Preserve the shared coroutine runtime for repository tests in the R8 process.
-keep class kotlinx.coroutines.** { *; }
