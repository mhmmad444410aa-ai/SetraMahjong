package com.mhmmad.setramahjong;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.view.*;
import com.huawei.hms.ads.*;
import com.huawei.hms.ads.banner.BannerView;
import com.huawei.hms.ads.consent.inter.Consent;
import com.huawei.hms.ads.consent.constant.ConsentStatus;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Test-device-only explicit consent fixture. Uses official test units only. */
public final class QaPetalProbe {
 public static String run(Instrumentation i,Activity a,GameViewModel vm)throws Exception {
  i.runOnMainSync(()->vm.setText("consent","declined"));Thread.sleep(1000);
  boolean hms=false;try{a.getPackageManager().getPackageInfo("com.huawei.hwid",0);hms=true;}catch(PackageManager.NameNotFoundException expected){}
  final CountDownLatch failures=new CountDownLatch(2);final AtomicReference<Throwable> thrown=new AtomicReference<>();final AtomicInteger bannerCode=new AtomicInteger(-999),interCode=new AtomicInteger(-999);
  final BannerView[] banner={null};final InterstitialAd[] inter={null};
  i.runOnMainSync(()->{try{
   for(String name:new String[]{"com.huawei.openalliance.ad.ppskit.provider.InnerApiProvider","com.huawei.openalliance.ad.provider.PPSECProvider"})a.getPackageManager().setComponentEnabledSetting(new ComponentName(a.getPackageName(),name),PackageManager.COMPONENT_ENABLED_STATE_ENABLED,PackageManager.DONT_KILL_APP);
   Consent.getInstance(a).setConsentStatus(ConsentStatus.NON_PERSONALIZED);
   HwAds.setRequestOptions(new RequestOptions.Builder().setNonPersonalizedAd(1).setTagForChildProtection(1).setAdContentClassification("W").build());HwAds.init(a);
   banner[0]=new BannerView(a);banner[0].setBannerAdSize(BannerAdSize.BANNER_SIZE_320_50);banner[0].setAdId("testw6vs28auh3");banner[0].setAdListener(new AdListener(){@Override public void onAdFailed(int code){bannerCode.set(code);failures.countDown();}});
   ((ViewGroup)a.getWindow().getDecorView()).addView(banner[0],new ViewGroup.LayoutParams(640,100));banner[0].loadAd(new AdParam.Builder().build());
   inter[0]=new InterstitialAd(a);inter[0].setAdId("teste9ih9j0rc3");inter[0].setAdListener(new AdListener(){@Override public void onAdFailed(int code){interCode.set(code);failures.countDown();}});inter[0].loadAd(new AdParam.Builder().build());
  }catch(Throwable e){thrown.set(e);}});
  if(thrown.get()!=null)throw new AssertionError("Real SDK initialisation failed",thrown.get());
  boolean failed=failures.await(22,TimeUnit.SECONDS);
  i.runOnMainSync(()->{if(banner[0]!=null){banner[0].destroy();if(banner[0].getParent() instanceof ViewGroup)((ViewGroup)banner[0].getParent()).removeView(banner[0]);}});
  if(!failed)throw new AssertionError("Expected two offline SDK failure callbacks, got banner="+bannerCode+" interstitial="+interCode);
  return "Real SDK offline callbacks: banner="+bannerCode+", interstitial="+interCode+", HMS installed="+hms+"; no advert was clicked";
 }
}
