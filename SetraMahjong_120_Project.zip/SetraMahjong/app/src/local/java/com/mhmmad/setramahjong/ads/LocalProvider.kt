package com.mhmmad.setramahjong.ads
import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
/** Offline release contains NO advertising SDK. This is not evidence of ad serving. */
fun createAdProvider(activity:Activity):AdProvider=object:AdProvider {
    override val privacy=kotlinx.coroutines.flow.MutableStateFlow(AdPrivacy())
    override fun requestPrivacy(){}
    override fun acceptPartners(granted:Boolean){}
    override fun permission(granted:Boolean){}
    override fun prepare(){}
    override fun transition(onShown:()->Unit){}
    @Composable override fun Banner(modifier:Modifier){}
    override fun close(){}
}
