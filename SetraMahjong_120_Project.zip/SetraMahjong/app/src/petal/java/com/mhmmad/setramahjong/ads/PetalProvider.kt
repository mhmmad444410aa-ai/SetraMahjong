package com.mhmmad.setramahjong.ads
import android.app.Activity
import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.mhmmad.setramahjong.BuildConfig
import com.mhmmad.setramahjong.R
import com.huawei.hms.ads.*
import com.huawei.hms.ads.banner.BannerView
import com.huawei.hms.ads.consent.inter.Consent
import com.huawei.hms.ads.consent.constant.ConsentStatus
import com.huawei.hms.ads.consent.inter.ConsentUpdateListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

fun createAdProvider(activity:Activity):AdProvider=PetalProvider(activity)
/** Only this source set references Petal; core and offline release cannot initialise it. */
private class PetalProvider(private val activity:Activity):AdProvider {
    private val privacyState=MutableStateFlow(AdPrivacy())
    override val privacy=privacyState.asStateFlow()
    private var permissionGranted=false
    private var checked=false
    private var checking=false
    private var enabled by mutableStateOf(false)
    private var interstitial:InterstitialAd?=null
    private var banner:BannerView?=null
    private val bannerId get()=if(BuildConfig.ADS_TEST_MODE)"testw6vs28auh3" else BuildConfig.BANNER_ID
    private val interstitialId get()=if(BuildConfig.ADS_TEST_MODE)"teste9ih9j0rc3" else BuildConfig.INTERSTITIAL_ID
    override fun permission(granted:Boolean) {
        val wasGranted=permissionGranted
        permissionGranted=granted
        if(!granted){enabled=false;interstitial=null;runCatching{banner?.destroy()};banner=null;providerComponents(false);if(wasGranted)runCatching{Consent.getInstance(activity.applicationContext).setConsentStatus(ConsentStatus.UNKNOWN)};return}
        if(!checked)requestPrivacy()else initialise()
    }
    override fun requestPrivacy() {
        if(checking)return
        checking=true
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({if(checking){checking=false;enabled=false;privacyState.value=AdPrivacy(failed=true)}},12000L)
        // Called only after explicit initial permission, or previously stored permission.
        runCatching {
            val c=Consent.getInstance(activity.applicationContext)
            c.requestConsentUpdate(object:ConsentUpdateListener {
                override fun onSuccess(status:ConsentStatus,needConsent:Boolean,providers:MutableList<com.huawei.hms.ads.consent.bean.AdProvider>?) {
                    if(!checking)return
                    checking=false;checked=true
                    val partners=providers.orEmpty().map{AdPartner(it.name?: "Petal Ads",it.privacyPolicyUrl?: "https://consumer.huawei.com/en/privacy/")}
                    if(permissionGranted&&status==ConsentStatus.NON_PERSONALIZED&&!needConsent){initialise()}
                    else if(permissionGranted&&status==ConsentStatus.NON_PERSONALIZED){initialise()}
                    else privacyState.value=AdPrivacy(partners=partners,review=true)
                }
                override fun onFail(description:String) {checking=false;enabled=false;privacyState.value=AdPrivacy(failed=true)}
            })
        }.onFailure{checking=false;enabled=false;privacyState.value=AdPrivacy(failed=true)}
    }
    override fun acceptPartners(granted:Boolean) {
        permissionGranted=granted;privacyState.value=AdPrivacy()
        runCatching{Consent.getInstance(activity.applicationContext).setConsentStatus(if(granted)ConsentStatus.NON_PERSONALIZED else ConsentStatus.UNKNOWN)}
        if(granted){checked=true;initialise()}else close()
    }
    private fun providerComponents(enable:Boolean) {
        listOf("com.huawei.openalliance.ad.ppskit.provider.InnerApiProvider","com.huawei.openalliance.ad.provider.PPSECProvider").forEach { name -> runCatching { activity.packageManager.setComponentEnabledSetting(android.content.ComponentName(activity.packageName,name),if(enable)android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,android.content.pm.PackageManager.DONT_KILL_APP) } }
    }
    private fun initialise() {
        if(enabled||!permissionGranted||!checked||bannerId.isBlank()||interstitialId.isBlank())return
        runCatching {
            // No location, storage, contacts or phone permissions are requested.
            HwAds.setRequestOptions(RequestOptions.Builder().setNonPersonalizedAd(1).setTagForChildProtection(1).setAdContentClassification("W").build())
            providerComponents(true)
            HwAds.init(activity.applicationContext)
            enabled=true;prepare()
        }.onFailure {enabled=false}
    }
    override fun prepare() {
        if(!enabled||!permissionGranted||interstitial!=null)return
        runCatching {
            interstitial=InterstitialAd(activity).apply {
                adId=interstitialId
                setVideoConfiguration(VideoConfiguration.Builder().setStartMuted(true).build())
                adListener=object:AdListener(){override fun onAdFailed(code:Int){interstitial=null};override fun onAdClosed(){interstitial=null}}
                loadAd(AdParam.Builder().build())
            }
        }.onFailure{interstitial=null}
    }
    override fun transition(onShown:()->Unit) {
        if(!enabled||!permissionGranted||activity.isFinishing||activity.isDestroyed)return
        val ad=interstitial?:return
        runCatching {if(ad.isLoaded){
            ad.adListener=object:AdListener(){override fun onAdOpened(){onShown()};override fun onAdClosed(){interstitial=null};override fun onAdFailed(code:Int){interstitial=null}}
            ad.show(activity)
        }}.onFailure{interstitial=null}
    }
    @Composable override fun Banner(modifier:Modifier) {
        if(!enabled||!permissionGranted)return
        Column(modifier.height(72.dp),horizontalAlignment=androidx.compose.ui.Alignment.CenterHorizontally) {
            Text(stringResource(R.string.advertisement),fontSize=9.sp)
            AndroidView(modifier=Modifier.width(320.dp).height(50.dp),factory={context->
                android.widget.FrameLayout(context).apply {
                    runCatching {
                        val adView=BannerView(context).apply {
                            layoutParams=ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
                            bannerAdSize=BannerAdSize.BANNER_SIZE_320_50
                            adId=bannerId
                        }
                        banner=adView;addView(adView)
                        adView.loadAd(AdParam.Builder().build())
                    }
                }
            },onRelease={frame->runCatching{(frame.getChildAt(0) as? BannerView)?.destroy()};banner=null})
        }
    }
    override fun close(){checking=false;enabled=false;providerComponents(false);runCatching{banner?.destroy()};banner=null;interstitial=null}
}
