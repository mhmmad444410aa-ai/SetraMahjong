package com.mhmmad.setramahjong;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.*;
import android.os.*;
import android.os.Process;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.mhmmad.setramahjong.engine.*;
import com.mhmmad.setramahjong.data.*;

/** Real Android instrumentation for the exact signed R8 target. No Espresso or
 * AndroidX test runtime is injected into the game process. Runs on a disposable
 * emulator: the full phase deliberately resets local progress. */
public class QaInstrumentation extends Instrumentation {
    private Bundle arguments;
    private MainActivity activity;
    private GameViewModel vm;
    private int checks;
    interface Check { boolean ok(); }
    @Override public void onCreate(Bundle a) { arguments=a;super.onCreate(a);start(); }
    @Override public void onStart() {
        Bundle result=new Bundle();
        try {
            String phase=arguments.getString("phase","full");
            log("PHASE="+phase+" PID="+Process.myPid());
            if(phase.equals("full")) migrationFixture();
            launch();
            check((getTargetContext().getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE)==0,"Release is not debuggable");
            if(phase.equals("full")) full();
            else if(phase.equals("prepare_restore")) prepareRestore();
            else if(phase.equals("restore")) restore();
            else if(phase.equals("large")) large();
            else if(phase.equals("motion")) motion();
            else if(phase.equals("motion_restore")) {waitFor(()->vm.getPrefs().getValue().getMatchStyle()==2,15000);check(vm.getPrefs().getValue().getMatchStyle()==2,"Selected match animation survives process death");}
            else if(phase.equals("ads")) {
                check(BuildConfig.PETAL_ENABLED && BuildConfig.ADS_TEST_MODE,"SDK test build uses official test IDs");
                Object message=Class.forName("com.mhmmad.setramahjong.QaPetalProbe").getMethod("run",Instrumentation.class,Activity.class,GameViewModel.class).invoke(null,this,activity,vm);
                check(true,String.valueOf(message));
                act(()->vm.start(14,"campaign",true));PairStep pair=Rules.INSTANCE.hint(s());int n=s().getRemaining();act(()->vm.tap(pair.getA()));act(()->vm.tap(pair.getB()));check(s().getRemaining()==n-2,"Gameplay remains functional after SDK network failures");
            }
            result.putString("stream","\nOK ("+checks+" checks)\n");finish(Activity.RESULT_OK,result);
        } catch(Throwable e) {
            try { shot("failure","qa-failure"); } catch(Throwable ignored) {}
            StringWriter writer=new StringWriter();e.printStackTrace(new PrintWriter(writer));
            result.putString("stream","\nFAILURES!!!\n"+writer);finish(Activity.RESULT_CANCELED,result);
        }
    }
    private void log(String s){Bundle b=new Bundle();b.putString("stream",s+"\n");sendStatus(1,b);}
    private void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;log("PASS "+message);}
    private void waitFor(Check condition,long ms) throws Exception {
        long end=SystemClock.uptimeMillis()+ms;
        while(!condition.ok()){if(SystemClock.uptimeMillis()>end)throw new AssertionError("Condition timed out, page="+(vm==null?"none":ui().getPage()));Thread.sleep(30);}
    }
    private GameUi ui(){return vm.getUi().getValue();}
    private Session s(){return ui().getSession();}
    private void act(Runnable action) throws Exception {
        final boolean[] accepted={false};
        while(!accepted[0]) {
            waitFor(()->!ui().getBusy(),15000);
            runOnMainSync(()->{if(!ui().getBusy()){action.run();accepted[0]=true;}});
        }
        waitFor(()->!ui().getBusy(),15000);Thread.sleep(85);
    }
    private void launch() throws Exception {
        Intent i=new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity=(MainActivity)startActivitySync(i);
        for(Field f:activity.getClass().getDeclaredFields())if(GameViewModel.class.isAssignableFrom(f.getType())){f.setAccessible(true);vm=(GameViewModel)f.get(activity);break;}
        if(vm==null)throw new AssertionError("Live ViewModel not found");
        waitFor(()->ui().getReady()&&!ui().getBusy(),30000);log("ACTIVITY_READY");
    }
    private void migrationFixture() throws Exception {
        Context c=getTargetContext();c.deleteDatabase("setra.db");File path=c.getDatabasePath("setra.db");path.getParentFile().mkdirs();
        SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(path,null);
        db.execSQL("CREATE TABLE sessions (slot TEXT NOT NULL PRIMARY KEY,payload TEXT NOT NULL,updated INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE completions (`key` TEXT NOT NULL PRIMARY KEY,level INTEGER NOT NULL,mode TEXT NOT NULL,stars INTEGER NOT NULL,seconds INTEGER NOT NULL,completedAt INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE totals (id INTEGER NOT NULL PRIMARY KEY,pairs INTEGER NOT NULL,hints INTEGER NOT NULL,undos INTEGER NOT NULL,shuffles INTEGER NOT NULL,seconds INTEGER NOT NULL,petals INTEGER NOT NULL)");
        Session old=Generator.INSTANCE.create(7,0x5345545241L+7*7919L,"campaign","campaign:7");
        db.execSQL("INSERT INTO sessions VALUES(?,?,?)",new Object[]{"campaign",SessionCodec.INSTANCE.encode(old),1L});
        db.execSQL("INSERT INTO totals VALUES(1,5,2,1,0,80,30)");db.setVersion(1);db.close();
    }
    private void full() throws Exception {
        check(ui().getSessions().get("campaign")!=null&&ui().getSessions().get("campaign").getLevel()==7,"Room migration restored original saved board");
        waitFor(()->vm.getTotals().getValue().getPetals()==30,10000);
        check(vm.getTotals().getValue().getPetals()==30,"Room migration preserved reward total");
        act(()->vm.reset());waitFor(()->ui().getSessions().isEmpty()&&vm.getTotals().getValue().getPetals()==0,15000);
        Thread.sleep(350);
        act(()->{vm.setBool("guideDone",true);vm.setBool("reduceMotion",true);vm.setText("language","en-GB");});
        check(getTargetContext().checkSelfPermission("android.permission.INTERNET")==PackageManager.PERMISSION_DENIED,"Default Release has no Internet permission");
        act(()->vm.start(14,"campaign",true));
        Session before=s();PairStep p=Rules.INSTANCE.hint(before);
        act(()->vm.hint());check(p.equals(ui().getHint()),"Hint identifies a genuinely free pair");
        runOnMainSync(()->{vm.tap(p.getA());for(int n=0;n<40;n++)vm.tap(p.getB());});waitFor(()->!ui().getBusy(),15000);
        check(s().getRemaining()==before.getRemaining()-2,"Rapid taps remove a pair only once");
        act(()->vm.undo());check(s().getTiles().equals(before.getTiles()),"Undo restores exact tile state");
        act(()->vm.shuffle());check(Rules.INSTANCE.validateSolution(s().getTiles(),s().getSolution()),"Shuffle produces a verified remaining solution");
        Session shuffled=s();act(()->vm.pause());long paused=ui().getElapsed();Thread.sleep(1300);
        check(ui().getElapsed()==paused,"Pause stops elapsed counter");act(()->vm.resume());check(s().getTiles().equals(shuffled.getTiles()),"Resume preserves shuffled symbols");
        for(int l=1;l<=12;l++){final int level=l;log("PLAY_LEVEL="+l);act(()->vm.start(level,"campaign",true));solve();check(s().getWon(),"Campaign level "+l+" cleared through live ViewModel");}
        waitFor(()->vm.getTotals().getValue().getPetals()==360,10000);
        act(()->vm.start(1,"campaign",true));solve();
        check(vm.getTotals().getValue().getPetals()==360,"Repeating a won level cannot award petals twice");
        for(String lang:new String[]{"en-GB","ar","pt-BR"}){
            log("LANGUAGE="+lang);act(()->vm.setText("language",lang));Thread.sleep(300);
            act(()->vm.navigate("home"));shot(lang+"_01_home","qa");
            act(()->vm.navigate("map"));shot(lang+"_02_journey","qa");
            act(()->vm.start(35,"campaign",true));shot(lang+"_03_board","qa");
            List<Tile> same=s().getTiles();act(()->vm.setText("language",lang.equals("ar")?"en-GB":"ar"));check(s().getTiles().equals(same),"Language switch preserves board in "+lang);act(()->vm.setText("language",lang));
            act(()->vm.navigate("daily"));shot(lang+"_04_daily","qa");
            act(()->vm.navigate("album"));shot(lang+"_05_album","qa");
            act(()->vm.navigate("stats"));shot(lang+"_06_statistics","qa");
            for(String page:new String[]{"settings","how","privacy","adprivacy","about"}){act(()->vm.navigate(page));shot(lang+"_"+page,"qa-navigation");}
            act(()->vm.start(1,"tutorial",true));solve();check(s().getWon(),"Interactive guide completed in "+lang);
            act(()->vm.navigate("home"));touch(lang);
        }
        act(()->vm.start(vm.dailyLevel(),"daily",true));solve();waitFor(()->vm.getTotals().getValue().getPetals()==390,10000);int petals=vm.getTotals().getValue().getPetals();
        check(petals==390,"Local daily completion grants one reward");act(()->vm.start(vm.dailyLevel(),"daily",true));solve();check(vm.getTotals().getValue().getPetals()==petals,"Daily reward cannot be granted twice");
        act(()->vm.setNumber("background",2));waitFor(()->vm.getPrefs().getValue().getBackground()==2,10000);check(true,"Unlocked background applies and persists through DataStore");act(()->vm.setNumber("background",0));
        act(()->{vm.setText("language","en-GB");vm.navigate("home");});
        check(vm.getCompletions().getValue().size()==13,"Real completion ledger has twelve campaign records and one daily record");
    }
    private void solve() throws Exception {List<PairStep> path=new ArrayList<>(s().getSolution());for(PairStep p:path){act(()->vm.tap(p.getA()));act(()->vm.tap(p.getB()));}}
    private AccessibilityNodeInfo find(AccessibilityNodeInfo n,String description){if(n==null)return null;if(description.contentEquals(n.getContentDescription()==null?"":n.getContentDescription()))return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=find(n.getChild(i),description);if(r!=null)return r;}return null;}
    private Rect bounds(String description) throws Exception {final AccessibilityNodeInfo[] node={null};waitFor(()->{node[0]=find(getUiAutomation().getRootInActiveWindow(),description);return node[0]!=null;},15000);Rect r=new Rect();node[0].getBoundsInScreen(r);return r;}
    private void event(long down,int action,float x,float y){MotionEvent e=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,x,y,0);e.setSource(InputDevice.SOURCE_TOUCHSCREEN);getUiAutomation().injectInputEvent(e,true);e.recycle();}
    private void click(float x,float y)throws Exception{long d=SystemClock.uptimeMillis();event(d,MotionEvent.ACTION_DOWN,x,y);Thread.sleep(65);event(d,MotionEvent.ACTION_UP,x,y);Thread.sleep(180);}
    private void drag(float x,float y,float dx)throws Exception{long d=SystemClock.uptimeMillis();event(d,MotionEvent.ACTION_DOWN,x,y);for(int i=1;i<=10;i++){Thread.sleep(30);event(d,MotionEvent.ACTION_MOVE,x+dx*i/10,y);}event(d,MotionEvent.ACTION_UP,x+dx,y);Thread.sleep(200);}
    private void touch(String lang)throws Exception{
        act(()->vm.start(1,"tutorial",true));Thread.sleep(300);
        String desc=lang.equals("ar")?"لوحة ماجونغ. باعد للتكبير واسحب للتحريك. استخدم التلميح لإظهار زوج متاح.":lang.equals("pt-BR")?"Tabuleiro de Mahjong. Amplie com dois dedos e arraste. Use Dica para realçar um par livre.":"Mahjong board. Pinch to zoom and drag to move. Use Hint to highlight an available pair.";
        Rect r=bounds(desc);float minX=Float.MAX_VALUE,minY=Float.MAX_VALUE,maxX=-Float.MAX_VALUE,maxY=-Float.MAX_VALUE;
        for(Tile t:s().getTiles()){minX=Math.min(minX,t.getX()*50+t.getZ()*6);maxX=Math.max(maxX,t.getX()*50+t.getZ()*6+100);minY=Math.min(minY,t.getY()*62-t.getZ()*9);maxY=Math.max(maxY,t.getY()*62-t.getZ()*9+132);}
        float base=Math.max(Math.min((r.width()-32)/(maxX-minX),(r.height()-24)/(maxY-minY)),42*activity.getResources().getDisplayMetrics().density/100);
        Rect plus=bounds(lang.equals("ar")?"تكبير":lang.equals("pt-BR")?"Ampliar":"Zoom in");click(plus.exactCenterX(),plus.exactCenterY());float scale=base*1.25f;
        Tile a=null,b=null;for(Tile t:s().getTiles()){if(t.getId()==0)a=t;if(t.getId()==3)b=t;}
        click(r.exactCenterX()+(a.getX()*50+a.getZ()*6+50-(minX+maxX)/2)*scale,r.exactCenterY()+(a.getY()*62-a.getZ()*9+60-(minY+maxY)/2)*scale);
        check(Integer.valueOf(0).equals(s().getSelectedId()),"Zoomed touch selects correct tile in "+lang);
        drag(r.left+r.width()*.45f,r.top+r.height()*.9f,80);float pan=Math.min(80,Math.max(0,((maxX-minX)*scale-r.width())/2)+25);
        click(r.exactCenterX()+pan+(b.getX()*50+b.getZ()*6+50-(minX+maxX)/2)*scale,r.exactCenterY()+(b.getY()*62-b.getZ()*9+60-(minY+maxY)/2)*scale);
        waitFor(()->!ui().getBusy(),15000);check(s().getRemaining()==6,"Touch after pan removes correct pair without RTL mirroring in "+lang);shot(lang+"_zoom_pan","qa-touch");
    }
    private void prepareRestore() throws Exception {
        act(()->{vm.setText("language","en-GB");vm.setBool("guideDone",true);});act(()->vm.start(35,"campaign",true));act(()->vm.shuffle());act(()->vm.hint());PairStep p=Rules.INSTANCE.hint(s());act(()->vm.tap(p.getA()));act(()->vm.tap(p.getB()));
        write("expected-session.json",SessionCodec.INSTANCE.encode(s()));write("previous-pid.txt",Integer.toString(Process.myPid()));shot("before_kill","qa-restore");check(s().getShuffles()==1&&s().getHistory().size()==1,"Prepared real saved shuffled session before process kill");
    }
    private void restore() throws Exception {
        Session expected=SessionCodec.INSTANCE.decode(read("expected-session.json"));Session actual=ui().getSessions().get("campaign");
        check(actual!=null&&actual.getTiles().equals(expected.getTiles()),"Process death restores exact shuffled tile list");check(actual.getHistory().equals(expected.getHistory()),"Process death restores undo history");check(actual.getSeed()==expected.getSeed()&&actual.getShuffles()==expected.getShuffles()&&actual.getHints()==expected.getHints(),"Process death restores seed and counters");check(!read("previous-pid.txt").equals(Integer.toString(Process.myPid())),"Restoration uses a different Android process");act(()->vm.continueGame());check(s().getTiles().equals(expected.getTiles()),"Continue resumes same board without regeneration");shot("after_kill","qa-restore");
    }
    private void large() throws Exception {
        for(String lang:new String[]{"ar","pt-BR","en-GB"}){act(()->vm.setText("language",lang));Thread.sleep(300);for(String p:new String[]{"home","settings","privacy","map"}){act(()->vm.navigate(p));shot(lang+"_"+p,"qa-large");}act(()->vm.start(35,"campaign",true));shot(lang+"_game","qa-large");check(s().getRemaining()>0,"Game and navigation run at large font in "+lang);}
    }
    private void motion() throws Exception {
        act(()->{vm.setText("language","ar");vm.setBool("guideDone",true);vm.setBool("reduceMotion",false);vm.setNumber("background",0);});
        waitFor(()->!vm.getPrefs().getValue().getReduceMotion(),15000);
        for(int style=0;style<3;style++) {
            final int choice=style;act(()->vm.setNumber("matchStyle",choice));waitFor(()->vm.getPrefs().getValue().getMatchStyle()==choice,15000);
            act(()->vm.start(14,"campaign",true));Thread.sleep(1000);
            PairStep pair=Rules.INSTANCE.hint(s());int before=s().getRemaining();
            act(()->vm.tap(pair.getA()));runOnMainSync(()->{vm.tap(pair.getB());for(int n=0;n<30;n++)vm.tap(pair.getB());});
            Thread.sleep(180);shotNow("motion_"+style,"qa-motion");waitFor(()->!ui().getBusy(),15000);
            check(s().getRemaining()==before-2,"Animated style "+style+" removes the pair exactly once and unlocks input");
            check(vm.getPrefs().getValue().getMatchStyle()==style,"Animated style "+style+" selected through saved DataStore preference");
        }
        act(()->vm.shuffle());Thread.sleep(850);check(Rules.INSTANCE.validateSolution(s().getTiles(),s().getSolution()),"Animated shuffle retains verified solvable geometry");shot("shuffle_after","qa-motion");
        act(()->vm.undo());Thread.sleep(700);check(s().getRemaining()>0,"Animated undo remains playable");
        act(()->vm.pause());check(s().getPaused(),"Pause works after animated actions");act(()->vm.resume());check(!s().getPaused(),"Resume works after animated actions");
        act(()->vm.setBool("reduceMotion",true));waitFor(()->vm.getPrefs().getValue().getReduceMotion(),15000);PairStep p=Rules.INSTANCE.hint(s());int before=s().getRemaining();act(()->vm.tap(p.getA()));act(()->vm.tap(p.getB()));check(s().getRemaining()==before-2,"Reduced motion keeps match rules and input functional");
        act(()->vm.setBool("reduceMotion",false));act(()->vm.navigate("home"));shot("redesigned_home","qa-motion");
        act(()->vm.navigate("settings"));shot("motion_settings","qa-motion");
    }
    private void shotNow(String name,String dir)throws Exception{Bitmap b=getUiAutomation().takeScreenshot();if(b==null)throw new AssertionError("Screenshot unavailable");try(FileOutputStream out=new FileOutputStream(new File(folder(dir),name+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
    private File folder(String name){File f=new File(getTargetContext().getExternalFilesDir(null),name);f.mkdirs();return f;}
    private void shot(String name,String dir)throws Exception{if(ui().getPage().equals("game")){String lang=vm.getPrefs().getValue().getLanguage();String desc=lang.equals("ar")?"لوحة ماجونغ. باعد للتكبير واسحب للتحريك. استخدم التلميح لإظهار زوج متاح.":lang.equals("pt-BR")?"Tabuleiro de Mahjong. Amplie com dois dedos e arraste. Use Dica para realçar um par livre.":"Mahjong board. Pinch to zoom and drag to move. Use Hint to highlight an available pair.";bounds(desc);}Thread.sleep(1100);Bitmap b=getUiAutomation().takeScreenshot();if(b==null)throw new AssertionError("Screenshot unavailable");try(FileOutputStream out=new FileOutputStream(new File(folder(dir),name+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
    private void write(String name,String value)throws Exception{try(FileOutputStream out=new FileOutputStream(new File(folder("qa-state"),name))){out.write(value.getBytes(StandardCharsets.UTF_8));}}
    private String read(String name)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(new File(folder("qa-state"),name))){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}
}
