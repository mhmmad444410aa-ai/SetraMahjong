# Error Prone's build-time annotation references a JDK-only enum, never called on Android.
-dontwarn javax.lang.model.element.Modifier

-keep class com.mhmmad.setramahjong.**Test { *; }
-keep class com.mhmmad.setramahjong.QaPetalProbe { public *; }
